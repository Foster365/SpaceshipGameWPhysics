﻿using System;
using System.Collections.Generic;

namespace Game
{
    public class Program
    {
        public enum ScreenFlow { level1Screen, level2Screen, level3Screen, pauseScreen, winScreen, gameOverScreen, exit }
        public static ScreenFlow actualState = ScreenFlow.level2Screen;

        //Variables selección de botones
        public static float timerSpace;
        public static float maxTimerSpace = .3f;
        public static bool canPressSpace = true;
        //

        public static int ScreenHeight = 600;
        public static int ScreenWidth = 800;

        public static Player player;

        static public Random randomPos = new Random();

        public static List<Enemy> Enemies = new List<Enemy>();
        public static List<Bullet> Bullets = new List<Bullet>();
        public static List<EnemyBullet> EnemyBullets = new List<EnemyBullet>();

        static public List<Image> Health;
        static public List<Image> Fuel;

        public static Level1Screen level1Screen;
        public static Level2Screen level2Screen;
        public static Level3Screen level3Screen;
        public static PauseScreen pauseScreen;
        public static CreditsScreen creditsScreen;
        public static WinScreen winScreen;
        public static GameOverScreen gameOverScreen;

        static void Main(string[] args)
        {

            Engine.Initialize("Inicializando", ScreenWidth, ScreenHeight);
            
            player = new Player(100, 300, 10, 100, 30, "Text/Player.png");

            level1Screen = new Level1Screen();
            level2Screen = new Level2Screen();
            level3Screen = new Level3Screen();
            pauseScreen = new PauseScreen();
            creditsScreen = new CreditsScreen();
            gameOverScreen = new GameOverScreen();
            winScreen = new WinScreen();
            
            while (true)
            {
                Time.DeltaTimeUpdate();
                Update();
                Render();
            }
        }
        
        static public void Update()
        {
            ScreensUpdate();

        }

        static private void ScreensUpdate()
        {

            if (actualState == ScreenFlow.level1Screen)
                level1Screen.Update();

            else if (actualState == ScreenFlow.level2Screen)
                level2Screen.Update();

            else if (actualState == ScreenFlow.level3Screen)
                level3Screen.Update();

            else if (actualState == ScreenFlow.pauseScreen)
                pauseScreen.Update();

            else if (actualState == ScreenFlow.gameOverScreen)
                gameOverScreen.Update();

            else if (actualState == ScreenFlow.winScreen)
                winScreen.Update();

            else if (actualState == ScreenFlow.exit)
                Environment.Exit(1);
        }
        
        static public void Render()
        {
            Engine.Clear();

            ScreensRender();

            Engine.Show();
            
        }

        static private void ScreensRender()
        {
            if (actualState == ScreenFlow.level1Screen)
                level1Screen.Render();

            if (actualState == ScreenFlow.level2Screen)
                level2Screen.Render();

            else if (actualState == ScreenFlow.level3Screen)
                level3Screen.Render();

            else if (actualState == ScreenFlow.pauseScreen)
                pauseScreen.Render();

            else if (actualState == ScreenFlow.gameOverScreen)
                gameOverScreen.Render();

            else if (actualState == ScreenFlow.winScreen)
                winScreen.Render();

        }

        static public void TextureLists()
        {
            Health = new List<Image>();
            Health.Add(new Image(40, 50, 404, 405, 0.05f, 0.05f, 0, "Text/LifeIcon.jpg"));
            Health.Add(new Image(70, 50, 404, 405, 0.05f, 0.05f, 0, "Text/LifeIcon.jpg"));
            Health.Add(new Image(100, 50, 404, 405, 0.05f, 0.05f, 0, "Text/LifeIcon.jpg"));

            Fuel = new List<Image>();
            Fuel.Add(new Image(660, 50, 209, 241, 0.2f, 0.2f, -90, "Text/Fuel.png"));
            Fuel.Add(new Image(710, 50, 209, 241, 0.2f, 0.2f, -90, "Text/Fuel.png"));
            Fuel.Add(new Image(760, 50, 209, 241, 0.2f, 0.2f, -90, "Text/Fuel.png"));
        }

    }
}