﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public static class BulletsFactory
    {
        public enum BulletFactory { bulletA, bulletB, bulletC, bulletD }

        public static Bullet CreateBullet(BulletFactory bullet, float positionX, float positionY, float angle)
        {
            switch (bullet)
            {
                //Agrego opcion para agregar posicion random
                case BulletFactory.bulletA:
                    return new Bullet(positionX, positionY, 1, angle, "Text/BulletA.png", 13, 13, 1, 1);
                case BulletFactory.bulletB:
                    return new Bullet(positionX, positionY, 1, angle, "Text/BulletB.png", 17, 17, 1, 1);
                case BulletFactory.bulletC:
                    return new Bullet(positionX, positionY, 1, angle, "Text/BulletC.png", 17, 17, 1, 1);
                default:
                    return new Bullet(positionX, positionY, 1, angle, "Text/BulletA.png", 13, 13, 1, 1);
            }
        }
        public enum EnemyBulletFactory { bulletA, bulletB, bulletC, bulletD }

        //public static EnemyBullet CreateEnemyBullet(EnemyBulletFactory enemyBullet, float positionX, float positionY, float angle)
        //{
        //    switch (enemyBullet)
        //    {
        //        //Agrego opcion para agregar posicion random
        //        case EnemyBulletFactory.bulletA:
        //            return new EnemyBullet(positionX, positionY, 1, angle, "Text/BulletA.png", 13, 13, 1, 1);
        //        case EnemyBulletFactory.bulletB:
        //            return new EnemyBullet(positionX, positionY, 1, angle, "Text/BulletB.png", 17, 17, 1, 1);
        //        case EnemyBulletFactory.bulletC:
        //            return new EnemyBullet(positionX, positionY, 1, angle, "Text/BulletC.png", 17, 17, 1, 1);
        //        case EnemyBulletFactory.bulletD:
        //            return new EnemyBullet(positionX, positionY, 1, angle, "Text/BulletC.png", 600, 200, 0.5f, 0.5f);
        //        default:
        //            return new EnemyBullet(positionX, positionY, 1, angle, "Text/BulletA.png", 13, 13, 1, 1);
        //    }
        //}

    }
}
