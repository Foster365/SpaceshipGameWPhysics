﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public static class EnemyFactory
    {
        public enum EnemiesFactory { enemyA, enemyB, enemyC, finalBossEnemy }
        
        public static Enemy CreateEnemy(EnemiesFactory enemy)
        {
            switch (enemy)
            {
                //Agrego opcion para agregar posicion random
                case EnemiesFactory.enemyA:
                    return new Enemy(Program.randomPos.Next(800, 850), Program.randomPos.Next(100, 600), 30, 10, 5, 10, 177, 189, .35f, .35f, "Text/EnemyA.png");
                case EnemiesFactory.enemyB:
                    return new Enemy(Program.randomPos.Next(900, 1000), Program.randomPos.Next(100, 600), 50, 50, 5, 15, 200, 400, .5f, .5f, "Text/EnemyB.png");
                case EnemiesFactory.enemyC:
                    return new Enemy(Program.randomPos.Next(800, 820), Program.randomPos.Next(100, 600), 20, 20, 10, 15, 400, 200, .5f, .5f, "Text/EnemyC.png");
                case EnemiesFactory.finalBossEnemy:
                    return new Enemy(Program.randomPos.Next(600, 650), Program.randomPos.Next(100, 600), 30, 10, 5, 10, 266, 259, .35f, .35f, "Text/EnemyBoss.png");
                default:
                    return new Enemy(Program.randomPos.Next(600, 650), Program.randomPos.Next(100, 600), 30, 10, 5, 10, 177, 189, .35f, .35f, "Text/EnemyA.png");
            }
        }
    }
}
