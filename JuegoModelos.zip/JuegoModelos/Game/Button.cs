﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Button
    {

        public float posX;
        public float posY;
        public Button buttonUp;
        public Button buttonDown;
        public string texture;
        public float timer = 0f;
        public float timeToPress = .2f;

        public Button(float posX, float posY, string texture)
        {

            this.posX = posX;
            this.posY = posY;

        }

        public void SetButtons(Button up, Button down)
        {

            buttonUp = up;
            buttonDown = down;

        }

        public Button Update()
        {
            timer += Time.DeltaTime;

            if (Engine.GetKey(Keys.UP) && timer >= timeToPress)
            {
                timer = 0f;
                return GetUp();
            }

            else if(Engine.GetKey(Keys.DOWN) && timer >= timeToPress)
            {
                timer = 0f;
                return GetDown();
            }

            else return this;
        }

        public void Render()
        {
            Engine.Draw(texture, posX, posY);
        }

        public Button GetUp()
        {
            if (buttonUp != null)
            {
                return buttonUp;
            }
            else return this;
        }

        public Button GetDown()
        {
            if (buttonDown != null)
            {
                return buttonDown;
            }
            else return this;
        }

    }
}
