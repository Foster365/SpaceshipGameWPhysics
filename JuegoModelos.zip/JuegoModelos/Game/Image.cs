﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Image
    {
        public float posX;
        public float posY;

        public float sizeX;
        public float sizeY;

        public float scaleX;
        public float scaleY;

        public float angle;
        public string texture;

        public Image(float posX, float posY, float sizeX, float sizeY, float scaleX, float scaleY, float angle, string texture)
        {
            this.posX = posX;
            this.posY = posY;

            this.sizeX = sizeX;
            this.sizeY = sizeY;

            this.scaleX = scaleX;
            this.scaleY = scaleY;

            this.angle = angle;
            this.texture = texture;
        }


        public float GetRealWidth()
        {
            return sizeX * scaleX;
        }

        public float GetRealHeight()
        {
            return sizeY * scaleY;
        }

        public void Render()
        {
            Engine.Draw(texture, posX, posY, scaleX, scaleY, angle, GetRealHeight() / 2, GetRealWidth() / 2);
        }
    }
}
