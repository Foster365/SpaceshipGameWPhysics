﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Player
    {
        //Variables

        public float rotation;
        public float playerScaleX;
        public float playerScaleY;

        public float playerSizeX;
        public float playerSizeY;
        public string playerTexture;

        public float playerPosX;
        public float playerPosY;

        public float playerSpeedX;
        public float playerSpeedY;

        public float playerAcelerationX;
        public float playerAcelerationY;

        public float playerForceX;
        public float playerForceY;

        public float angle;
        public float angularSpeed;
        public float angularAceleration;

        public float playerMass;

        public int life;
        public bool destroyed;
        public float radius;

        //Calculos combustible

        float capacity;
        float totalCapacity;
        float density;
        float dieselOilHeatOfCombustion;
        float heatOfCombustion;
        float eficiency;

        float work;
        float workX;
        float workY;

        float initialEnergy;
        float energy;

        float energyPerc;

        bool isMoving;

        float timeToShoot;
        float shootTime = 0.5f;
        //

        public Player(float playerPosX, float playerPosY, float playerMass, int life, float radius, string playerTexture)
        {

            this.life = life;
            this.radius = radius;
            timeToShoot = 0.8f;

            this.playerPosX = playerPosX;
            this.playerPosY = playerPosY;

            playerSpeedX = 0;
            playerSpeedY = 0;
            playerAcelerationX = 0;
            playerAcelerationY = 0;
            playerForceX = 0;
            playerForceY = 0;

            angle = 0;
            angularSpeed = 0;
            angularAceleration = 0;

            this.playerMass = playerMass;

            this.playerTexture = playerTexture;

            playerScaleX = 0.125f; playerScaleY = 0.125f;
            playerSizeX = 920; playerSizeY = 609;
            rotation = 90;

            capacity = 10;//m^3
            density = 680;//kg/m^3
            dieselOilHeatOfCombustion = 42700000;//j/Kg diesel oil
            eficiency = .3f;

            destroyed = false;
            isMoving = false;

        }

        public float GetRealHeight()
        {
            return playerSizeY * playerScaleY;
        }

        public float GetRealWidth()
        {
            return playerSizeX * playerScaleX;
        }

        public void Update()
        {
            if (!destroyed)
            {

                timeToShoot += Time.DeltaTime;//Timer para disparar

                float dirX = (float)Math.Cos(angle * Math.PI / 180) * 1;

                float dirY = (float)Math.Sin(angle * Math.PI / 180) * 1;

                if (Engine.GetKey(Keys.W))
                {
                    ApplyForce(dirX * 500, dirY * 500);
                }

                if (Engine.GetKey(Keys.S))
                {
                    ApplyForce(dirX * (-500), dirY * (-500));
                }
                
                angularAceleration = 0;

                if (Engine.GetKey(Keys.D))//Apreto W y me muevo con fuerza en y (Para arriba, por eso aplico fuerza negativa)
                {
                    angularAceleration += 30;
                }

                if (Engine.GetKey(Keys.A))
                {
                    angularAceleration += -30;
                }

                PhysicsCalculus();
                

                CheckScreenLimits();
                CheckShoot();//Chequeo si puedo disparar
                CheckForCollisions();


                CheckVictory();//Chequeo victoria
                CheckDefeat();//Chequeo derrota
            }
        }

        public void ApplyForce(float _forceX, float _forceY)
        {
            playerForceX += _forceX;
            playerForceY += _forceY;

        }

        //Tuve que sacar las ec. horarias porque no funcionaba el mov del personaje.
        public void PhysicsCalculus()
        {
            //Realizo los mismos cálculos pero en este los hago en x e y porque el jugador se mueve en ambas
            playerAcelerationX = playerForceX / playerMass;
            playerAcelerationY = playerForceY / playerMass;

            playerPosX += playerSpeedX * Time.DeltaTime + 0.5f * playerAcelerationX * Time.DeltaTime * Time.DeltaTime;
            playerPosY += playerSpeedY * Time.DeltaTime + 0.5f * playerAcelerationY * Time.DeltaTime * Time.DeltaTime;

            playerSpeedX += playerAcelerationX * Time.DeltaTime;
            playerSpeedY += playerAcelerationY * Time.DeltaTime;

            totalCapacity = capacity * density;//Ver como usar la misma capacidad
            heatOfCombustion = dieselOilHeatOfCombustion * eficiency;

            workX = playerForceX * playerPosX;
            
            workY = playerForceY * playerPosY;

            work = workX + workY;
                
            initialEnergy = totalCapacity * heatOfCombustion;

            energy = initialEnergy;
            energy = energy - work;//Primera ley de conservación de la energía
            Console.WriteLine("Avaiable Energy" + energy);

            energyPerc = (energy * 100) / (totalCapacity*heatOfCombustion);
            Console.WriteLine("Energy perc" + energyPerc + "%");

            playerForceX = 0;
            playerForceY = 0;

            playerAcelerationX = 0;
            playerAcelerationY = 0;

            //Angles

            angularSpeed += angularAceleration * Time.DeltaTime;
            angle += angularSpeed * Time.DeltaTime + 0.5f * angularAceleration * Time.DeltaTime * Time.DeltaTime;

        }

        public void CombustibleCalculus()
        {


        }

        public void CheckShoot()//Chequeo si puedo disparar
        {
            if (Engine.GetKey(Keys.SPACE) && timeToShoot >= shootTime)//Si apreto space y el timer llegó al límite disparo
            {
                Shoot();
            }
        }

        public void CheckScreenLimits()
        {
            if (playerPosX < 0)
            {
                playerPosX = 0;
                playerSpeedX = 0;
            }

            if (playerPosX > Program.ScreenWidth)
            {
                playerPosX = Program.ScreenWidth;
                playerSpeedX = 0;
            }

            if (playerPosY < 0)
            {
                playerPosY = 0;
                playerSpeedY = 0;
            }

            if (playerPosY > Program.ScreenHeight)
            {
                playerPosY = Program.ScreenHeight;
                playerSpeedY = 0;
            }
        }

        public void Shoot()//Cuando disparo creo una nueva bala (Con la pos del jugador para que spawnee donde estoy, una masa y la textura 
        {
            Bullet bullet = new Bullet(playerPosX, playerPosY, 1, angle, "Text/BulletB.png", 17, 17, 1, 1);
            timeToShoot = 0;//Reseteo el timer
        }

        public void CheckForCollisions()//Chequeo colisiones con el enemigo (Con cada enemigo de la lista, por eso recorro con for)
        {
            for (int i = 0; i < Program.Enemies.Count; i++)
                CheckForCollisionsWEnemy(Program.Enemies[i]);
        }

        public void CheckForCollisionsWEnemy(Enemy enemy)//Cálculo de colisiones
        {
            float diffX = Math.Abs(playerPosX - enemy.enemyPosX);
            float diffY = Math.Abs(playerPosY - enemy.enemyPosY);

            float sumaMitadAncho = GetRealWidth() / 2 + enemy.GetRealWidth() / 2;
            float sumaMitadAlto = GetRealHeight() / 2 + enemy.GetRealHeight() / 2;

            if (diffX <= sumaMitadAncho && diffY <= sumaMitadAlto)
            {
                GetDamage(enemy.enemyDamage);
                Engine.Debug("Coll");
            }

        }

        public void GetDamage(int damage)//Función de quitar vida
        {
            life -= damage;//le resto vida al daño

            for (int i = 3; i < Program.Health.Count; i++)
            {
                if (life == life - life * .3f)
                    Program.Health.Remove(Program.Health[i]);
            }

            Engine.Debug("Vida" + life);
            CheckDefeat();

        }

        public void CheckDefeat()
        {

            if (life <= 0)//Si la vida llega a 0 se destruye, pongo la vida en 0 y pierde la partida
            {
                destroyed = true;
                life = 0;
                Program.actualState = Program.ScreenFlow.gameOverScreen;
            }
        }

        public void CheckVictory()//Chequeo la victoria, si no hay más enemigos en la lista y tengo vida gano (Llamo a la función win de program)
        {
            if (Program.actualState == Program.ScreenFlow.level3Screen && Program.Enemies.Count == 0 && life >= 0)
                Program.actualState = Program.ScreenFlow.winScreen;

        }

        public void Draw()
        {
            if(!destroyed)
                Engine.Draw(playerTexture, playerPosX, playerPosY, playerScaleX, playerScaleY, angle+90, GetRealWidth() / 2, GetRealHeight() / 2);
            
        }

    }
}
