﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Arrow
    {
        public float posX;
        public float posY;
        public float offset = 30f;
        public float angle = 90;
        public float sizeX = 920;
        public float sizeY = 609;
        public float scaleX = .2f;
        public float scaleY = .2f;
        public string texture = "Text/Player.png";

        public void Update(float x, float y)
        {
            posX = x - offset;
            posY = y;

        }

        public float GetRealHeight()
        {
            return sizeY * scaleY;
        }

        public float GetRealWidth()
        {
            return sizeX * scaleX;
        }

        public void Render()

        {
            Engine.Draw(texture, posX, posY, scaleX, scaleY, angle, GetRealWidth()/2, GetRealHeight()/2);
        }
    }
}
