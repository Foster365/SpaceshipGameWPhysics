﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class EnemyBullet
    {
        //Variables

        public float rotation;
        public float bulletScaleX;
        public float bulletScaleY;

        public float bulletSizeX;
        public float bulletSizeY;
        public string bulletTexture;

        public float angle;

        public float bulletPosX;
        public float bulletPosY;

        public float bulletSpeedX;
        public float bulletSpeedY;

        public float bulletAcelerationX;
        public float bulletAcelerationY;

        public float bulletForceX;
        public float bulletForceY;

        public float bulletMass;

        public int damage;
        public bool destroyed;
        public int radius;
        public int bulletDamage;

        float lifeSpan = 2f;
        float timer;
        //

        // Constructor (Me sirve para crear un objeto con determinadas variables)
        //Pongo solo la posición y masa (En cuanto a físicas) porque las demás variables se calculan en PhysicsCalculus()
        public EnemyBullet(float bulletPosX, float bulletPosY, float bulletMass, float angle, string bulletTexture, float bulletSizeX, float bulletSizeY, float bulletScaleX, float bulletScaleY)
        {
            this.bulletPosX = bulletPosX;//Uso this. porque la variable de afuera es la misma que la variable del constructor
            this.bulletPosY = bulletPosY;
            bulletSpeedX = 0;//Las seteo en 0
            bulletSpeedY = 0;
            bulletAcelerationX = 0;
            bulletAcelerationY = 0;
            bulletForceX = 0;
            bulletForceY = 0;

            this.bulletMass = bulletMass;

            this.bulletTexture = bulletTexture;

            this.angle = angle;

            this.bulletSizeX = bulletSizeX;
            this.bulletSizeY = bulletSizeY;

            this.bulletScaleX = bulletScaleX;
            this.bulletScaleY = bulletScaleY;

            radius = 10;
            bulletDamage = 5;

            rotation = 0;
            timer = 0;

            destroyed = false;//Si esta en true el objeto está destruido

            Program.EnemyBullets.Add(this);//Agrego la bala a la lista de balas de program
        }

        public float GetRealHeight()//Obtengo el alto real de la imagen
        {
            return bulletSizeY * bulletScaleY;
        }

        public float GetRealWidth()//Obtengo el ancho real de la imagen
        {
            return bulletSizeX * bulletScaleX;
        }

        public void Update()
        {
            if (!destroyed && timer >= lifeSpan)
                Deactivate();
            else if (!destroyed)
            {
                timer += Time.DeltaTime;//Hace correr el timer, lifetime de mi bala
                CheckForCollisions();
                ApplyForces(-300, 0);//Aplico fuerza en x
                PhysicsCalculus();//Calculos de físicas
            }
            //Mantener el orden de estas funciones, para que se mueva de manera correcta


        }

        public void Deactivate()
        {
            destroyed = true;//Voy a eliminar la bala así que destroyed es verdadero

            Program.EnemyBullets.Remove(this);//Remuevo la bala (Esta bala) de la lista de balas de program

        }

        public void PhysicsCalculus()//Calculos física
        {

            bulletAcelerationX = bulletForceX / bulletMass;//Aceleración, tomo la fuerza de ApplyForces() y la masa que paso por constructor en program

            bulletPosX += bulletSpeedX * Time.DeltaTime + 0.5f * bulletAcelerationX * Time.DeltaTime * Time.DeltaTime;//Calculo posición con los valores que tengo

            bulletSpeedX += bulletAcelerationX * Time.DeltaTime;//Calculo velocidad

            bulletForceX = 0;//Reseteo fuerzas
            bulletForceY = 0;

            bulletAcelerationX = 0;//Reseteo aceleraciones
            bulletAcelerationY = 0;

        }

        public void ApplyForces(float _forceX, float _forceY)
        {
            bulletForceX += _forceX;//Sumo fuerza en x
            bulletForceY += _forceY;//La sumo en y
        }

        public void CheckForCollisions()//Chequeo colisiones con el enemigo (Con cada enemigo de la lista, por eso recorro con for)
        {
               CheckForCollisionsWPlayer(Program.player);
        }

        public void CheckForCollisionsWPlayer(Player player)//Cálculo de colisiones
        {
            float diffX = Math.Abs(bulletPosX - player.playerPosX);
            float diffY = Math.Abs(bulletPosY - player.playerPosY);

            float sumaMitadAncho = GetRealWidth() / 2 + player.GetRealWidth() / 2;
            float sumaMitadAlto = GetRealHeight() / 2 + player.GetRealHeight() / 2;

            if (diffX <= sumaMitadAncho && diffY <= sumaMitadAlto)
            {
                player.GetDamage(damage);
            }

        }

        public void Draw()
        {
            if (!destroyed)
                Engine.Draw(bulletTexture, bulletPosX, bulletPosY, bulletScaleX, bulletScaleY, rotation, GetRealWidth() / 2, GetRealHeight() / 2);//Dibujo el objeto

        }
    }
}