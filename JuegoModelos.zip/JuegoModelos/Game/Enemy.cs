﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Enemy
    {
        public float rotation;
        public float enemyScaleX;
        public float enemyScaleY;

        public float enemySizeX;
        public float enemySizeY;
        public string enemyTexture;

        public float enemyPosX;
        public float enemyPosY;

        public float enemySpeedX;
        public float enemySpeedY;

        public float enemyAcelerationX;
        public float enemyAcelerationY;

        public float enemyForceX;
        public float enemyForceY;

        public float enemyMass;

        public int enemyLife;
        public int enemyDamage;
        public int radius;

        float timeToShoot;
        float timer;

        public bool destroyed;

        public enum EnemyAnimations { death };
        public EnemyAnimations actualEnemyState = EnemyAnimations.death;
        public Animation enemyDeath;

        //

        public Enemy(float enemyPosX, float enemyPosY, float enemyMass, int enemyLife, int radius, int enemyDamage, float enemySizeX, float enemySizeY, float enemyScaleX, float enemyScaleY, string enemyTexture)
        {

            this.enemyLife = enemyLife;
            timeToShoot = 2;
            timer = 0;
            this.radius = radius;

            this.enemyPosX = enemyPosX;
            this.enemyPosY = enemyPosY;

            this.enemySizeX = enemySizeX;
            this.enemySizeY = enemySizeY;

            this.enemyScaleX = enemyScaleX;
            this.enemyScaleY = enemyScaleY;

            enemySpeedX = 0;
            enemySpeedY = 0;
            enemyAcelerationX = 0;
            enemyAcelerationY = 0;
            enemyForceX = 0;
            enemyForceY = 0;

            this.enemyMass = enemyMass;

            this.enemyTexture = enemyTexture;
            
            rotation = 90;

            this.enemyDamage = enemyDamage;

            destroyed = false;
            SetAnimationParameters();

        }

        public float GetRealWidth()
        {
            return enemySizeX * enemyScaleX;
        }

        public float GetRealHeight()
        {
            return enemySizeY * enemyScaleY;
        }

        public void Update()
        {
            if (!destroyed)
            {
                timer += Time.DeltaTime;

                ApplyForce(800, 0);

                PhysicsCalculus();

                CheckShoot();
            }

            CheckForCollisions();

            UpdateAnimation();

        }

        public void CheckForCollisions()//Chequeo colisiones con el enemigo (Con cada enemigo de la lista, por eso recorro con for)
        {
            CheckForCollisionsWPlayer(Program.player);
        }

        public void CheckForCollisionsWPlayer(Player player)//Cálculo de colisiones
        {
            float diffX = Math.Abs(enemyPosX - player.playerPosX);
            float diffY = Math.Abs(enemyPosY - player.playerPosY);

            float sumaMitadAncho = GetRealWidth() / 2 + player.GetRealWidth() / 2;
            float sumaMitadAlto = GetRealHeight() / 2 + player.GetRealHeight() / 2;

            if (diffX <= sumaMitadAncho && diffY <= sumaMitadAlto)
            {
                player.GetDamage(enemyDamage);
            }

        }
        public void ApplyForce(float _forceX, float _forceY)
        {
            enemyForceX += _forceX;

        }

        public void PhysicsCalculus()
        {
            enemyAcelerationX = enemyForceX / enemyMass;

            enemyPosX -= enemySpeedX * Time.DeltaTime + 0.5f * enemyAcelerationX * Time.DeltaTime * Time.DeltaTime;

            enemySpeedX += enemyAcelerationX * Time.DeltaTime;

            enemyForceX = 0;

            enemyAcelerationX = 0;

        }

        public void CheckShoot()//Chequeo si puedo disparar
        {
            if (timer >= timeToShoot)//Si apreto space y el timer llegó al límite disparo
            {
                Shoot();
            }
        }

        public void Shoot()//Cuando disparo creo una nueva bala (Con la pos del jugador para que spawnee donde estoy, una masa y la textura 
        {
            new EnemyBullet(enemyPosX, enemyPosY, 1, 0, "Text/BulletD.png", 600, 200, 0.05f, 0.05f);
            timer = 0;//Reseteo el timer
        }

        public void Draw()
        {
            if(!destroyed)
                Engine.Draw(enemyTexture, enemyPosX, enemyPosY, enemyScaleX, enemyScaleY, rotation, GetRealWidth() / 2, GetRealHeight() / 2);

        }

        public void SetAnimationParameters()
        {

            List<Texture> enemyDeathFrames = new List<Texture>();
            for (int i = 0; i < 15; i++)
            {
                enemyDeathFrames.Add(Engine.GetTexture("Text/Explosion/" + i.ToString() + ".png"));
            }

            enemyDeath = new Animation(enemyDeathFrames, false, 1);


        }

        public void UpdateAnimation()
        {
            if (actualEnemyState == EnemyAnimations.death)
            {
                actualEnemyState = EnemyAnimations.death;
                enemyDeath.Play();
            }
        }

    }
}
