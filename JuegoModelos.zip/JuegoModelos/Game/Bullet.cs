﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Bullet
    {
        //Variables

        public float rotation;
        public float bulletScaleX;
        public float bulletScaleY;

        public float bulletSizeX;
        public float bulletSizeY;
        public string bulletTexture;

        public float bulletPosX;
        public float bulletPosY;

        public float bulletSpeedX;
        public float bulletSpeedY;

        public float bulletAcelerationX;
        public float bulletAcelerationY;

        public float bulletForceX;
        public float bulletForceY;

        public float bulletMass;

        public float angle;

        public bool destroyed;
        public int radius;
        public int bulletDamage;

        float lifeSpan = 2f;
        float timer;
        
        //

        // Constructor (Me sirve para crear un objeto con determinadas variables)
        //Pongo solo la posición y masa (En cuanto a físicas) porque las demás variables se calculan en PhysicsCalculus()
        public Bullet(float bulletPosX, float bulletPosY, float bulletMass, float angle, string bulletTexture, float bulletSizeX, float bulletSizeY, float bulletScaleX, float bulletScaleY)
        {
            this.bulletPosX = bulletPosX;//Uso this. porque la variable de afuera es la misma que la variable del constructor
            this.bulletPosY = bulletPosY;

            this.angle = angle;

            bulletSpeedX = 0;//Las seteo en 0
            bulletSpeedY = 0;
            var bulletForce = 20000;
            bulletAcelerationX = -bulletForce * (float)Math.Cos(angle * Math.PI / 180) / bulletMass;
            bulletAcelerationY = -bulletForce * (float)Math.Sin(angle * Math.PI / 180) / bulletMass;
            bulletForceX = 0;
            bulletForceY = 0;

            this.bulletMass = bulletMass;

            this.bulletTexture = bulletTexture;

            this.bulletSizeX = bulletSizeX;
            this.bulletSizeY = bulletSizeY;

            this.bulletScaleX = bulletScaleX;
            this.bulletScaleY = bulletScaleY;

            radius = 10;
            bulletDamage = 100;
            
            timer = 0;

            destroyed = false;//Si esta en true el objeto está destruido

            Program.Bullets.Add(this);//Agrego la bala a la lista de balas de program
        }
        
        public float GetRealHeight()//Obtengo el alto real de la imagen
        {
            return bulletSizeY * bulletScaleY;
        }

        public float GetRealWidth()//Obtengo el ancho real de la imagen
        {
            return bulletSizeX * bulletScaleX;
        }
        
        public void Update()
        {
            if (!destroyed && timer >= lifeSpan)
                Deactivate();
            else if (!destroyed)
            {
                timer += Time.DeltaTime;//Hace correr el timer, lifetime de mi bala
                CheckForCollisions();
                PhysicsCalculus();//Calculos de físicas
            }
            //Mantener el orden de estas funciones, para que se mueva de manera correcta
            
           
        }

        public void Deactivate()
        {

            destroyed = true;//Voy a eliminar la bala así que destroyed es verdadero
            
            Program.Bullets.Remove(this);//Remuevo la bala (Esta bala) de la lista de balas de program

        }
        
        public void PhysicsCalculus()//Calculos física
        {

            //bulletSpeedX += bulletAcelerationX * Time.DeltaTime;//Calculo velocidad
            //bulletSpeedY += bulletAcelerationY * Time.DeltaTime;//Calculo velocidad

            bulletSpeedX += bulletAcelerationX*Time.DeltaTime;
            bulletSpeedY += bulletAcelerationY*Time.DeltaTime;

            bulletPosX -= bulletSpeedX * Time.DeltaTime; /* + 0.5f * bulletAcelerationX * Time.DeltaTime * Time.DeltaTime;*///Calculo posición con los valores que tengo
            bulletPosY -= bulletSpeedY * Time.DeltaTime; /* + 0.5f * bulletAcelerationY * Time.DeltaTime * Time.DeltaTime;*///Calculo posición con los valores que tengo

            bulletForceX = 0;//Reseteo fuerzas
            bulletForceY = 0;

            bulletAcelerationX = 0;//Reseteo aceleraciones
            bulletAcelerationY = 0;

        }
        
        public void ApplyForces(float _forceX, float _forceY)
        {
            bulletForceX += _forceX;//Sumo fuerza en x
            bulletForceY += _forceY;//La sumo en y
        }

        public void CheckForCollisions()//Chequeo colisiones con el enemigo (Con cada enemigo de la lista, por eso recorro con for)
        {
            for (int i = 0; i < Program.Enemies.Count; i++)
            {
                CheckForCollisionsWEnemy(Program.Enemies[i]);
            }
        }

        public void CheckForCollisionsWEnemy(Enemy enemy)//Cálculo de colisiones
        {
            float diffX = Math.Abs(bulletPosX - enemy.enemyPosX);
            float diffY = Math.Abs(bulletPosY - enemy.enemyPosY);

            float sumaMitadAncho = GetRealWidth() / 2 + enemy.GetRealWidth() / 2;
            float sumaMitadAlto = GetRealHeight() / 2 + enemy.GetRealHeight() / 2;

            if (diffX <= sumaMitadAncho && diffY <= sumaMitadAlto)
            {
                enemy.destroyed = true;

                Program.Enemies.Remove(enemy);
                Engine.Debug("Enemy bull collision");

            }

            //if (Program.Enemies.Count == 0)
            //    Program.Win();

        }
        
        public void Draw()
        {
            if (!destroyed)
                Engine.Draw(bulletTexture, bulletPosX, bulletPosY, bulletScaleX, bulletScaleY, angle * (float)Math.PI / 180, GetRealWidth() / 2, GetRealHeight() / 2);//Dibujo el objeto
            
            //if (enemy.destroyed==true&&actualEnemyState==EnemyAnimations.death)
            //    Engine.Draw(enemyDeath.animFrames[enemyDeath.actualAnimationFrame], enemy.enemyPosX, enemy.enemyPosY, 0.5f, 0.5f);

        }
    }
}