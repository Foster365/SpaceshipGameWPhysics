﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Level1Screen
    {
        public float timer;//Timer para crear enemigos
        public float createEnemyTimer;
        public float count;

        public Image backgroundlevel;
        public Image bgDetails;

        public enum Animations { levelTimer };

        public Animations actualAnimState = Animations.levelTimer;

        public Animation levelTimer;

        public Level1Screen()
        {

            timer = 0;//Timer para crear enemigos
            createEnemyTimer = 1;
            count = 0;

            ResetLevel();
        }

        public void Update()
        {

            timer += Time.DeltaTime;//Corro timer, cuando llega al límite creo un enemigo

            if (timer >= createEnemyTimer)
            {
                CreateEnemy();
                timer = 0;
            }

            for (int i = 0; i < Program.Bullets.Count; i++)
                Program.Bullets[i].Update();

            for (int i = 0; i < Program.EnemyBullets.Count; i++)
                Program.EnemyBullets[i].Update();

            for (int i = 0; i < Program.Enemies.Count; i++)
                Program.Enemies[i].Update();

            //Program.player.Update();

            LevelTimer();
            UpdateAnimation();
            CheckLevelWin();

            //if (levelTimer.actualAnimationFrame == 0)
            //    Program.actualState = Program.ScreenFlow.gameOverScreen;

        }

        public void Render()
        {
            Engine.Clear();

            backgroundlevel.Render();
            bgDetails.Render();

            for (int i = 0; i < Program.Bullets.Count; i++)//Dibujo balas
                Program.Bullets[i].Draw();

            for (int i = 0; i < Program.EnemyBullets.Count; i++)
                Program.EnemyBullets[i].Draw();

            for (int i = 0; i < Program.Enemies.Count; i++)//Dibujo enemigos, recorro lista con for por cada elemento
                Program.Enemies[i].Draw();

            for (int i = 0; i < Program.Health.Count; i++)
                Program.Health[i].Render();

            for (int i = 0; i < Program.Fuel.Count; i++)
                Program.Fuel[i].Render();

            //Program.player.Draw();//Dibujo jugador

            if (actualAnimState == Animations.levelTimer)
                Engine.Draw(levelTimer.animFrames[levelTimer.actualAnimationFrame], 750, 550, 0.5f, 0.5f);

        }

        public void ResetLevel()
        {

            backgroundlevel = new Image(0, 600, 1920, 1080, 1, 1, 0, "Text/Background.png");
            bgDetails = new Image(400, 300, 2362, 1449, 0.5f, 0.5f, 0, "Text/Bg_Details.png");

            SetAnimationParameters();

            Program.TextureLists();

        }

        public void CreateEnemy()
        {

            //Vector2 enemyPosition = new Vector2(random.Next(600, 750), random.Next(0, 500));

            if (timer >= createEnemyTimer && Program.Enemies.Count < 10)//Si el timer llega al límite creo un enemigo
            {

                Program.Enemies.Add(EnemyFactory.CreateEnemy(EnemyFactory.EnemiesFactory.enemyA));
                count++;

                //Program.Enemies.Add(new Enemy(800, randomPos.Next(0, 600), 30, 10, 5, 10, "Text/Enemy.png"));//Agrego un enemigo a la lista de enemigos
            }

        }

        public void LevelTimer()
        {
            float gameOverTimer = 60;
            float timer = 0;

            //Correr animación de timer

            timer += Time.DeltaTime;

            if (timer >= gameOverTimer)
                Program.actualState = Program.ScreenFlow.gameOverScreen;

        }

        public void SetAnimationParameters()
        {

            List<Texture> levelCounterFrames = new List<Texture>();
            for (int i = 30; i > 0; i--)
            {
                levelCounterFrames.Add(Engine.GetTexture("Text/Countdown/" + i.ToString() + ".png"));
            }

            levelTimer = new Animation(levelCounterFrames, false, 1);


        }

        public void UpdateAnimation()
        {
            if (actualAnimState == Animations.levelTimer)
            {
                actualAnimState = Animations.levelTimer;
                levelTimer.Play();
            }
        }

        public void CheckLevelWin()
        {
            if (Program.Enemies.Count == 0 && levelTimer.actualAnimationFrame > 0)
                Program.actualState = Program.ScreenFlow.level2Screen;
        }

        public void CheckDefeat()
        {
            if (levelTimer.actualAnimationFrame < 1)
                Program.actualState = Program.ScreenFlow.gameOverScreen;
        }

    }
}
