﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class CreditsScreen
    {
        //    public Arrow arrow;
        //    public Button backButton;
        //    public Button actualButton;
        //    public List<Button> botones = new List<Button>();

        //    public CreditsScreen()
        //    {
        //        // Inicializo los botones pasandoles la posicion y la textura
        //        backButton = new Button(260f, 450f, "Texturas/VolverBtn.png");
        //        botones.Add(backButton);

        //        // Les paso el boton que tendran abajo y arriba (null si no tienen)
        //        backButton.SetButtons(null, null);

        //        actualButton = backButton;

        //        arrow = new Arrow();
        //        arrow.Update(actualButton.posX, actualButton.posY);
        //    }

        //    public void Actualizar()
        //    {
        //        // Actualizo los botones
        //        actualButton = actualButton.Update();

        //        // Actualizo la flecha
        //        arrow.Update(actualButton.posX, actualButton.posY);

        //        // Chequeo si seleccionp un boton
        //        if (Engine.GetKey(Keys.SPACE) && Program.canPressSpace)
        //        {
        //            Program.canPressSpace = false;
        //            Program.timerSpace = 0f;
        //            EnterButton();
        //        }
        //    }

        //    public void Render()
        //    {
        //        // Dibujo el fondo
        //        Engine.Draw("Texturas/Creditos.png");

        //        // Dibujo los botones
        //        foreach (var boton in botones)
        //        {
        //            boton.Render();
        //        }

        //        // Dibujo la flecha
        //        arrow.Render();
        //    }

        //    private void EnterButton()
        //    {
        //        if (actualButton == backButton)
        //        {
        //            Program.actualState = Program.ScreenFlow.mainMenuScreen;
        //        }
        //    }
    }

}
