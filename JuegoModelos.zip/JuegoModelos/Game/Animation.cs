﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Animation
    {
        public bool isLoop;
        public string name;
        public float speed;
        public int actualAnimationFrame;
        public List<Texture> animFrames = new List<Texture>();
        public float time;

        public Animation(List<Texture> animFrames, bool isloop, float speed)
        {

            this.animFrames = animFrames;
            this.isLoop = isloop;
            this.speed = speed;

        }

        public void Play()
        {
            time += Time.DeltaTime;

            if (time >= speed)
            {
                actualAnimationFrame++;
                time = 0f;

                if (actualAnimationFrame >= animFrames.Count)
                {
                    actualAnimationFrame = 0;
                }
            }
        }

    }
}
